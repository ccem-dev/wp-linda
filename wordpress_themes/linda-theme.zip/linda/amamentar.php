<?php
/*Template Name:amamentar */

get_header();
?>
<!-- Wrapper -->
<div id="wrapper">

  <!-- Main -->
  <div id="main">
    <div class="inner">



      <!-- Content -->
      <section>
        <header class="major">

          <h2>Como amamentar</h2>
        </header>
        <p>Seu bebê está mamando de forma adequada?</p>
        <h3>Boa Posição</h3>
        <ol>
          <li>O pescoço do bebê está ereto ou um pouco curvado para trás, sem estar distendido;</li>
          <li>A boca está bem aberta;</li>
          <li>O corpo da criança está voltado para o corpo da mãe;</li>
          <li>A barriga do bebê está encostada na barriga da mãe;</li>
          <li>Todo o corpo do bebê recebe sustentação;</li>
          <li>O bebê e a mãe devem estar confortáveis;</li>
        </ol>
        <img src="<?php bloginfo("template_directory"); ?>/images/posicao.png" width="500" alt="" />
      </section>

      <section>
        <h3>Boa Pega</h3>
        <ol>
          <li>O queixo toca a mama;</li>
          <li>O lábio inferior está virado para fora;</li>
          <li>Há mais aréola visível acima da boca do que abaixo;</li>
          <li>A barriga do bebê está encostada na barriga da mãe;</li>
          <li>Todo o corpo do bebê recebe sustentação;</li>
          <li>Ao amamentar, a mãe não sente dor no mamilo;</li>
        </ol>
        <img src="<?php bloginfo("template_directory"); ?>/images/pega.png" width="500" alt="" />

      </section>


    </div>
  </div>

  <!-- Sidebar -->
  <div id="sidebar">
    <div class="inner">

      <?php get_sidebar(); ?>


    </div>
  </div>

</div>

<!-- Scripts -->
<script src="<?php bloginfo("template_directory"); ?>/assets/js/jquery.min.js"></script>
<script src="<?php bloginfo("template_directory"); ?>/assets/js/browser.min.js"></script>
<script src="<?php bloginfo("template_directory"); ?>/assets/js/breakpoints.min.js"></script>
<script src="<?php bloginfo("template_directory"); ?>/assets/js/util.js"></script>
<script src="<?php bloginfo("template_directory"); ?>/assets/js/main.js"></script>

</body>
</html>
