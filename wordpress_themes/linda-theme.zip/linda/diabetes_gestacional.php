<?php
/*Template Name:diabetes gestacional */

get_header();
?>

<!-- Wrapper -->
<div id="wrapper">

  <!-- Main -->
  <div id="main">
    <div class="inner">



      <!-- Content -->
      <section>
        <h2>O que é diabetes gestacional?</h2>
        <p>É o diabetes detectado durante a gravidez e que pode ser tratado, beneficiando a mãe e o bebê. Após a gravidez o diabetes
          costuma ir emobra, mas retorna mais tarde com muita frequência.</p>
        <p>O diabetes tipo 2 é uma doença grave, que pode causar muitos problemas. É importante
        saber que ele pode ser prevenido. E, quando ele ocorrer, poderá ser tratado para evitar complicações.</p>


      </section>
      <span class="image main" style="opacity: 0.4;width: 8%; position: fixed;bottom:10px;right:10px;float: right;margin: 0;padding: 0" ><img src="<?php bloginfo("template_directory"); ?>/images/recrutamento.png" alt=""/></span>


    </div>
  </div>

  <!-- Sidebar -->
  <div id="sidebar">
    <div class="inner">

      <?php get_sidebar(); ?>

    </div>
  </div>

</div>

<!-- Scripts -->
<script src="<?php bloginfo("template_directory"); ?>/assets/js/jquery.min.js"></script>
<script src="<?php bloginfo("template_directory"); ?>/assets/js/browser.min.js"></script>
<script src="<?php bloginfo("template_directory"); ?>/assets/js/breakpoints.min.js"></script>
<script src="<?php bloginfo("template_directory"); ?>/assets/js/util.js"></script>
<script src="<?php bloginfo("template_directory"); ?>/assets/js/main.js"></script>

</body>
</html>
