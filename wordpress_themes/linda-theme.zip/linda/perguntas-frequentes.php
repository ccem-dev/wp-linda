<?php
/*Template Name:perguntas frequentes */

get_header();
?>
<!-- Wrapper -->
<div id="wrapper">

  <!-- Main -->
  <div id="main">
    <div class="inner">



      <!-- Content -->
      <section>
        <header class="major">
        <h2>Perguntas Frequentes</h2>
        </header>
        <ul>
          <li><b>O bebê pode continuar com fome depois de mamar?</b></li>
          <span><i>Sim, se o bebê não tomar o leite do fim da mamada, que tem mais gordura, ele pode sentir fome logo em seguida. Durante a mamada, a quantidade de gordura do leite vai aumentando.
          Por isso, a mãe deve esvaziar a mama por completo para depois oferecer a outra. Mas lembre-se que nem todo choro do bebê é de fome.</i></span>
          <br>
          <br>
          <li><b>É normal que meu bebê mame muitas vezes ao dia?</b></li>
          <span><i>Sim, principalmente nos primeiros meses é normal que os bebês mamem muitas vezes ao dia, de dia e de noite.</i></span>
          <br>
          <br>
          <li><b>Meu leite pode ser fraco?</b></li>
          <span><i>Não existe leite fraco! TOdo leite materno é forte e bom. A cor do leite pode variar, mas ele nunca é fraco.</i></span>

        </ul>


      </section>
      <span class="image main" style="opacity: 0.4;width: 25%; position: fixed;bottom:10px;right:10px;float: right;margin: 0;padding: 0" ><img src="<?php bloginfo("template_directory"); ?>/images/mae-e-bebe.png" alt=""/></span>


    </div>
  </div>

  <!-- Sidebar -->
  <div id="sidebar">
    <div class="inner">

      <?php get_sidebar(); ?>


    </div>
  </div>

</div>

<!-- Scripts -->
<script src="<?php bloginfo("template_directory"); ?>/assets/js/jquery.min.js"></script>
<script src="<?php bloginfo("template_directory"); ?>/assets/js/browser.min.js"></script>
<script src="<?php bloginfo("template_directory"); ?>/assets/js/breakpoints.min.js"></script>
<script src="<?php bloginfo("template_directory"); ?>/assets/js/util.js"></script>
<script src="<?php bloginfo("template_directory"); ?>/assets/js/main.js"></script>

</body>
</html>
