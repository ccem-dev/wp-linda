<?php
/*Template Name:dicas importantes */

get_header();
?>
<!-- Wrapper -->
<div id="wrapper">

  <!-- Main -->
  <div id="main">
    <div class="inner">



      <!-- Content -->
      <section>
        <header class="major">
        <h2>Dicas Importantes</h2>
        </header>
        <ul>
          <li>Até os 6 meses, dê somente leite materno para o seu bebê. Não dê água, chás, leites artificiais ou qualquer outro alimento.</li>
          <li>A partir dos 6 meses, você pode começar a dar
            outros alimentos, mas mantendo o leite materno.</li>
          <li>Não dê mamadeira pois isso pode levar o bebê
            a rejeitar o peito da mãe. Quando necessário, o leite
            materno pode ser dado no copinho.</li>
          <li>Tome muita água. Uma dica é tomar água
            sempre antes ou logo após a mamada.</li>
          <li>Faça pelo menos três refeições (café da manhã,
            almoço e jantar) e dois lanches saudáveis por dia,
            dando preferência aos alimentos na sua forma mais
            natural</li>
          <li>Procure consumir diariamente pelo menos três
            porções de legumes e verduras como parte das
            refeições, e três porções ou mais de frutas nos lanches e
            sobremesas.</li>
        </ul>


      </section>
      <span class="image main" style="opacity: 0.4;width: 25%; position: fixed;bottom:10px;right:10px;float: right;margin: 0;padding: 0" ><img src="<?php bloginfo("template_directory"); ?>/images/mae-e-bebe.png" alt=""/></span>


    </div>
  </div>

  <!-- Sidebar -->
  <div id="sidebar">
    <div class="inner">

      <?php get_sidebar(); ?>


    </div>
  </div>

</div>

<!-- Scripts -->
<script src="<?php bloginfo("template_directory"); ?>/assets/js/jquery.min.js"></script>
<script src="<?php bloginfo("template_directory"); ?>/assets/js/browser.min.js"></script>
<script src="<?php bloginfo("template_directory"); ?>/assets/js/breakpoints.min.js"></script>
<script src="<?php bloginfo("template_directory"); ?>/assets/js/util.js"></script>
<script src="<?php bloginfo("template_directory"); ?>/assets/js/main.js"></script>

</body>
</html>
