<?php
/*Template Name:apoiando */

get_header();
?>
<!-- Wrapper -->
<div id="wrapper">

  <!-- Main -->
  <div id="main">
    <div class="inner">

      <!-- Content -->
      <section>
        <header class="major">
          <h2>Família e amigos apoiando a amamentação</h2>
        </header>
        <p>O pai do bebê, família e amigos podem ajudar a mãe para que ela possa amamentar com tranquilidade.</p>
        <h2>O que o pai pode fazer?</h2>
        <span>- Colocar o bebê para arrotar - o peito do pai é ótimo para isso!</span><br>
        <span>- Ajudar com as tarefas de casa.</span><br>
        <p>- Ajudar nas tarefas com o bebê, como dar banho e trocar as fraldas.</p>
        <span class="image main"><img src="<?php bloginfo("template_directory"); ?>/images/ajuda-pai.png" style="width: 300px" alt=""/></span>

      </section>
      <section>
        <h2>O que a família e os amigos podem fazer?</h2>
        <span>- Dar o apoio emocional e ajudar nas tarefas do dia-a-dia com fazer compras, preparar refeições e limpar a casa.</span><br>
        <span>- Cuidar dos irmãos e irmãs maiores.</span>
        <p>- Ouvir e dar apoio, incentivando a mãe a amamentar.</p>
        <span class="image main"><img src="<?php bloginfo("template_directory"); ?>/images/ajuda-familia.png" style="width: 300px" alt=""/></span>

      </section>


    </div>
  </div>

  <!-- Sidebar -->
  <div id="sidebar">
    <div class="inner">

      <?php get_sidebar(); ?>


    </div>
  </div>

</div>

<!-- Scripts -->
<script src="<?php bloginfo("template_directory"); ?>/assets/js/jquery.min.js"></script>
<script src="<?php bloginfo("template_directory"); ?>/assets/js/browser.min.js"></script>
<script src="<?php bloginfo("template_directory"); ?>/assets/js/breakpoints.min.js"></script>
<script src="<?php bloginfo("template_directory"); ?>/assets/js/util.js"></script>
<script src="<?php bloginfo("template_directory"); ?>/assets/js/main.js"></script>

</body>
</html>
