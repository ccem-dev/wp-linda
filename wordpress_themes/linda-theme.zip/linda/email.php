<?php
/*Template Name:email */

get_header();
?>
<!-- Wrapper -->
<div id="wrapper">

  <!-- Main -->
  <div id="main">
    <div class="inner">



      <!-- Content -->
      <section>
        <header class="major">
          <h2>ENTRE EM CONTATO</h2>
        </header>
        <!-- Form -->
        <h3>Preencha os campos abaixo!</h3>
        <?php
        @$response = $_GET["sending"];
        if(!empty($response)){
          if($response == "true"){
            echo "<p>Mensagem enviada com sucesso.</p>";
          } else if($response == "false"){
            echo "<p>Não foi possível enviar a mensagem.</p>";
          }
        }
        ?>

        <form method="post" action="<?php bloginfo("template_directory"); ?>/sending.php" id="formContact">
          <div class="row gtr-uniform">
            <div class="col-6 col-12-xsmall">
              <label for="name">Nome</label>
              <input type="text" name="name" id="name" value="" placeholder="Nome Completo" required/>
            </div>
            <div class="col-6 col-12-xsmall">
              <label for="telephone">Telefone</label>
              <input type="tel" name="telephone" id="telephone" value="" placeholder="Ex.: 51987654321" required/>
            </div>
            <div class="col-12">
              <label for="email">Email</label>
              <input type="email" name="email" id="email" value="" required placeholder="Email" />
            </div>
            <!-- Break -->
<!--            <div class="col-12">-->
<!--              <select name="demo-category" id="demo-category">-->
<!--                <option value="">- Cidade -</option>-->
<!--                <option value="Porto Alegre">Porto Alegre</option>-->
<!--                <option value="1">Shipping</option>-->
<!--                <option value="1">Administration</option>-->
<!--                <option value="1">Human Resources</option>-->
<!--              </select>-->
<!--            </div>-->
            <!-- Break -->

            <!-- Break -->
            <div class="col-12">
              <label for="message">Mensagem</label>
              <textarea name="message" id="message" placeholder="Escreva sua mensagem" rows="6" required></textarea>
            </div>
            <!-- Break -->
            <div class="col-12">
              <input type="checkbox" id="human" name="human"/>
              <label for="human">Eu não sou um robô!</label>
            </div>
            <div class="col-12">
              <ul class="actions">
                <li><input type="submit" id="btnSend" value="Enviar" class="primary" disabled="true" /></li>
                <li><input type="reset" value="Limpar" /></li>
              </ul>
            </div>
          </div>

        </form>
      </section>


    </div>
  </div>

  <!-- Sidebar -->
  <div id="sidebar">
    <div class="inner">

      <?php get_sidebar(); ?>


    </div>
  </div>

</div>

<!-- Scripts -->
<script src="<?php bloginfo("template_directory"); ?>/assets/js/jquery.min.js"></script>
<script src="<?php bloginfo("template_directory"); ?>/assets/js/browser.min.js"></script>
<script src="<?php bloginfo("template_directory"); ?>/assets/js/breakpoints.min.js"></script>
<script src="<?php bloginfo("template_directory"); ?>/assets/js/util.js"></script>
<script src="<?php bloginfo("template_directory"); ?>/assets/js/main.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/jquery.maskedinput/1.4.1/jquery.maskedinput.min.js"></script>
<script>
  $(document).ready(function () {

    $("#human").click(function () {
      if ($('#human').is(":checked"))
      {
        $('#btnSend').removeAttr("disabled");
      } else {
        $("#btnSend").attr("disabled", true);
      }
    })

    $("#formContact").on('reset', function (e) {
      $("#btnSend").attr("disabled", true);
    });

    jQuery("#telephone")
      .mask("(99) 9999-9999?9")
      .focusout(function (event) {
        var target, phone, element;
        target = (event.currentTarget) ? event.currentTarget : event.srcElement;
        phone = target.value.replace(/\D/g, '');
        element = $(target);
        element.unmask();
        if(phone.length > 10) {
          element.mask("(99) 99999-999?9");
        } else {
          element.mask("(99) 9999-9999?9");
        }
      });

  });
</script>
</body>
</html>
