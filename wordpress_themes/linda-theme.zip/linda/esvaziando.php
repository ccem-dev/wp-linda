<?php
/*Template Name:esvaziando */

get_header();
?>
<!-- Wrapper -->
<div id="wrapper">

  <!-- Main -->
  <div id="main">
    <div class="inner">

      <!-- Content -->
      <section>
        <header class="major">

          <h2>Esvaziando a mama sem a ajuda do bebê</h2>
        </header>
        <p>O esvaziamento das mamas é importante para aliviar mamas muito cheias, manter a produção de leite quando a
          mãe precisa se afastar do bebê ou para doar a um banco de leite.</p>
      </section>
      <section>
        <h3>Como fazer</h3>


        <div class="table-wrapper">
          <table class="alt">
            <thead>
            <tr>
              <th>Ilustrações</th>
              <th>Passos</th>
            </tr>
            </thead>
            <tbody>
            <tr>
              <td><img src="<?php bloginfo("template_directory"); ?>/images/passo1.png" width="120" alt=""/></td>
              <td>
                <p style="margin-top: -35px; margin-bottom: 0px; top: -20px;position: relative; display: inline-block">
                  <b>PASSO 1:</b> Massageie as mamas com as pontos dos dedos, fazendo movimentos circulares no sentido
                  da parte escura (aréola) para o corpo.
                </p>
              </td>
            </tr>
            <tr>
              <td><img src="<?php bloginfo("template_directory"); ?>/images/passo2.png" width="120" alt=""/></td>
              <td>
                <p style="margin-top: -35px; margin-bottom: 0px; top: -35px;position: relative; display: inline-block">
                  <b>PASSO 2:</b> Coloque o polegar acima da linha onde acaba a aréola e os dedos indicador e médio
                  abaixo da aréola, firmando-os e empurrando para trás em direção ao corpo.
                </p>
              </td>
            </tr>
            <tr>
              <td><img src="<?php bloginfo("template_directory"); ?>/images/passo3.png" width="120" alt=""/></td>
              <td>
                <p style="margin-top: -35px; margin-bottom: 0px; top: -40px;position: relative; display: inline-block">
                  <b>PASSO 3:</b> Pressione e solte, pressione e solte. No começo , o leite pode não fluir, mas depois
                  de pressionar algumas vezes, o leite começa a sair com mais facilidade.
                </p></td>
            </tr>
            <tr>
              <td><img src="<?php bloginfo("template_directory"); ?>/images/passo4.png" width="120" alt=""/></td>
              <td>
                <p style="margin-top: -35px; margin-bottom: 0px; top: -45px;position: relative; display: inline-block">
                  <b>PASSO 4:</b> Pressione os lados para esvaziar todos os segmentos. Alterne a mama quando o fluxo do
                  leite diminuir e repita o procedimento várias vezes.
                </p>
              </td>
            </tr>
            </tbody>
            <tfoot>
            <tr>

              <td><b>Lembre-se:</b></td>
              <td>
                - Se a técnica estiver correta, <b>não deve doer.</b><br>
                - As duas mamas podem ser esvaziadas ao mesmo tempo.
              </td>
            </tr>
            </tfoot>
          </table>
        </div>
      </section>


    </div>
  </div>

  <!-- Sidebar -->
  <div id="sidebar">
    <div class="inner">

      <?php get_sidebar(); ?>


    </div>
  </div>

</div>

<!-- Scripts -->
<script src="<?php bloginfo("template_directory"); ?>/assets/js/jquery.min.js"></script>
<script src="<?php bloginfo("template_directory"); ?>/assets/js/browser.min.js"></script>
<script src="<?php bloginfo("template_directory"); ?>/assets/js/breakpoints.min.js"></script>
<script src="<?php bloginfo("template_directory"); ?>/assets/js/util.js"></script>
<script src="<?php bloginfo("template_directory"); ?>/assets/js/main.js"></script>

</body>
</html>
