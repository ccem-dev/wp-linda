<?php
/**
 * The sidebar containing the main widget area
 *
 * @link https://developer.wordpress.org/themes/basics/template-files/#template-partials
 *
 * @package Linda
 */


?>

<div id="secondary" class="widget-area">

		<!-- <section id="search" class="alt">
			<form method="post" action="#">
				<input type="text" name="query" id="query" placeholder="Search" />
			</form>
		</section> -->
		<nav id="menu">
			<header class="major">
				<h2>Menu</h2>
			</header>
			<ul>
				<li><a href="http://localhost/">INÍCIO</a></li>
				<li><a href="http://localhost/elementos">ELEMENTOS</a></li>
				<li>
					<span class="opener">DIABETES</span>
					<ul>
						<li><a href="http://localhost/diabetes">O que é diabetes?</a></li>
						<li><a href="http://localhost/gestacional">O que é diabetes gestacional?</a></li>
					</ul>
				</li>
        <li><a href="http://localhost/acompanhamento">Acompanhamento e prevenção</a></li>
<!--        <li><a href="http://localhost/aleitamento">Aleitamento Materno</a></li>-->
<!--        <li><a href="--><?php //bloginfo("template_directory"); ?><!--/elements.html">Elements</a></li>-->
<!--				<li><a href="#">Etiam Dolore</a></li>-->
<!--				<li><a href="#">Adipiscing</a></li>-->
<!--				<li><a href="#">Adipiscing</a></li>-->
				<li>
					<span class="opener">Aleitamento Materno</span>
					<ul>
						<li><a href="http://localhost/aleitamento">Orientações</a></li>
						<li><a href="http://localhost/amamentar">Como amamentar</a></li>
						<li><a href="http://localhost/esvaziando">Esvaziando a mama sem a ajuda do bebê</a></li>
						<li><a href="http://localhost/armazenar">Como armazenar o leite retirado</a></li>
						<li><a href="http://localhost/apoiando">Família e amigos apoiando a amamentação</a></li>
						<li><a href="http://localhost/dicas-importantes">Dicas impotantes</a></li>
						<li><a href="http://localhost/perguntas-frequentes">Perguntas frequentes</a></li>
					</ul>
				</li>
        <li><a href="http://localhost/recomendacoes/">Recomendações à mãe que amamenta</a></li>
<!--				<li><a href="#">Maximus Erat</a></li>-->
<!--				<li><a href="#">Sapien Mauris</a></li>-->
<!--				<li><a href="#">Amet Lacinia</a></li>-->
			</ul>
		</nav>

<!--		<section>-->
<!--			<header class="major">-->
<!--				<h2>Ante interdum</h2>-->
<!--			</header>-->
<!--			<div class="mini-posts">-->
<!--				<article>-->
<!--					<a href="#" class="image"><img src="--><?php //bloginfo("template_directory"); ?><!--/images/pic07.jpg" alt="" /></a>-->
<!--					<p>Aenean ornare velit lacus, ac varius enim lorem ullamcorper dolore aliquam.</p>-->
<!--				</article>-->
<!--				<article>-->
<!--					<a href="#" class="image"><img src="--><?php //bloginfo("template_directory"); ?><!--/images/pic08.jpg" alt="" /></a>-->
<!--					<p>Aenean ornare velit lacus, ac varius enim lorem ullamcorper dolore aliquam.</p>-->
<!--				</article>-->
<!--				<article>-->
<!--					<a href="#" class="image"><img src="--><?php //bloginfo("template_directory"); ?><!--/images/pic09.jpg" alt="" /></a>-->
<!--					<p>Aenean ornare velit lacus, ac varius enim lorem ullamcorper dolore aliquam.</p>-->
<!--				</article>-->
<!--			</div>-->
<!--			<ul class="actions">-->
<!--				<li><a href="#" class="button">More</a></li>-->
<!--			</ul>-->
<!--		</section>-->
<!---->
  <section>
    <span></span>
  </section>
		<section style="margin-top: 50px;">
      <header class="major">
        <h2>Contatos</h2>
      </header>
      <ul class="contact">
				<li class="fa-envelope-o"><a href="mailto:linda.brasil@ufrgs.br">linda.brasil@ufrgs.br</a></li>
				<li class="fa-telegram"><a href="http://localhost/email">Envie uma mensagem!</a></li>
<!--				<li class="fa-phone">(000) 000-0000</li>-->
				<li class="fa-home">Rua Ramiro Barcelos, 2600 / 419. <br />Porto Alegre - RS</li>
			</ul>
		</section>

</div><!-- #secondary -->
