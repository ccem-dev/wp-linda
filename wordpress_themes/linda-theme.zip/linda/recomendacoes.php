<?php
/*Template Name:Recomendações */

get_header();
?>
<!-- Wrapper -->
<div id="wrapper">

  <!-- Main -->
  <div id="main">
    <div class="inner">



      <!-- Content -->
      <section>
        <header class="major">
          <h2>RECOMENDAÇÕES À MÃE QUE AMAMENTA</h2>
        </header>
        <div class="features" >
          <article>
            <span class="icon"><img src="<?php bloginfo("template_directory"); ?>/images/icon-flor.png" width="60" alt="" style="margin-top:55px"/></span>
            <div class="content">
              <p>Tome um copo de água a cada refeição e sempre que tiver sede.</p>
            </div>
          </article>
          <article>
            <span class="icon"><img src="<?php bloginfo("template_directory"); ?>/images/icon-flor.png" width="60" alt="" style="margin-top:55px"/></span>
            <div class="content">
              <p>Coma diariamente alimentos in natura, variando entre os vários tipos de verduras, legumes, frutas, feijões, arroz, batata e outras raízes.</p>
            </div>
          </article>
          <article>
            <span class="icon"><img src="<?php bloginfo("template_directory"); ?>/images/icon-flor.png" width="60" alt="" style="margin-top:55px"/></span>
            <div class="content">
              <p>Ingira alimentos ricos em proteína, como carne e ovos. Não é necessário ingeri-los diariamente. Prefira carne branca, especialmente peixes.</p>
            </div>
          </article>
          <article>
            <span class="icon"><img src="<?php bloginfo("template_directory"); ?>/images/icon-flor.png" width="60" alt="" style="margin-top:55px"/></span>
            <div class="content">
              <span>Ingira alimentos ricos em cálcio, por exemplo:
              <ul>
                <li>1 xícara de leite (ou iogurte natural); 1 fatia de queijo; 1/2 xícara de coalhada;</li>
                <li>sardinha enlatada (evite a versão com óleo);</li>
                <li>soja em grãos;</li>
                <li>lentilha com espinafre; feijão com couve; grão-de-bico com brócolis.</li>
              </ul>
              </span>
            </div>
          </article>
          <article>
            <span class="icon"><img src="<?php bloginfo("template_directory"); ?>/images/icon-flor.png" width="60" alt="" style="margin-top:55px"/></span>
            <div class="content">
              <p>Procure ficar ao ar livre por 20 minutos (entre 7h e 9h ou entre 16h e 18h) para receber a quantidade de sol necessária para seu corpo gerar vitamina D.</p>
            </div>
          </article>
          <article>
            <span class="icon"><img src="<?php bloginfo("template_directory"); ?>/images/icon-flor.png" width="60" alt="" style="margin-top:55px"/></span>
            <div class="content">
              <p>Evite a ingestão de bebidas alcoólicas e não fume.</p>
            </div>
          </article>

        </div>

      </section>


    </div>
  </div>

  <!-- Sidebar -->
  <div id="sidebar">
    <div class="inner">

      <?php get_sidebar(); ?>


    </div>
  </div>

</div>

<!-- Scripts -->
<script src="<?php bloginfo("template_directory"); ?>/assets/js/jquery.min.js"></script>
<script src="<?php bloginfo("template_directory"); ?>/assets/js/browser.min.js"></script>
<script src="<?php bloginfo("template_directory"); ?>/assets/js/breakpoints.min.js"></script>
<script src="<?php bloginfo("template_directory"); ?>/assets/js/util.js"></script>
<script src="<?php bloginfo("template_directory"); ?>/assets/js/main.js"></script>

</body>
</html>
