<?php
/*Template Name:aleitamento */

get_header();
?>
<!-- Wrapper -->
<div id="wrapper">

  <!-- Main -->
  <div id="main">
    <div class="inner">



      <!-- Content -->
      <section>
        <header class="major">
          <h2>Orientações para o Aleitamento Materno</h2>
        </header>
        <h3>Por que amamentar no peito o seu bebê?</h3>
        <p>Amamentar faz bem para o bebê e também para a mãe.</br>
        O leite materno é um alimento completo. Só ele garante tudo o que o bebê precisa nos primeiros 6 meses de vida e continua sendo um excelente alimento mesmo
        depois disso. Ao amamentar, a mãe transmite amor, carinho, segurança, saúde e proteção. O leite meterno vem <b>pronto</b>, <b>limpo</b> e na <b>temperatura adequada</b>.</p>


      </section>

      <section>
        <h3>Para a criança</h3>
        <div class="features" >
          <article>
            <span class="icon"><img src="<?php bloginfo("template_directory"); ?>/images/icon-flor.png" width="60" alt="" style="margin-top:55px"/></span>
            <div class="content">
              <p>Protege contra infecções e outras doenças como diarreia, infecções respiratórias e otites, pois os anticorpos da mãe são passados pelo leite.</p>
            </div>
          </article>
          <article>
            <span class="icon"><img src="<?php bloginfo("template_directory"); ?>/images/icon-flor.png" width="60" alt="" style="margin-top:55px"/></span>
            <div class="content">
              <p>Protege contra doenças crõnicas, como alergias, diabetes e pressão alta.</p>
            </div>
          </article>
          <article>
            <!--            <span class="icon fa-bar-chart"></span>-->
            <span class="icon"><img src="<?php bloginfo("template_directory"); ?>/images/icon-flor.png" width="60" alt="" style="margin-top:55px"/></span>
            <div class="content">
              <p>Ajuda no desenvolvimento da face da criança, fazendo com que ela tenha dentes fortes e bonitos, desenvolva a fala e tenha boa respiração.</p>
            </div>
          </article>
          <article>
            <span class="icon"><img src="<?php bloginfo("template_directory"); ?>/images/icon-flor.png" width="60" alt="" style="margin-top:55px"/></span>
            <!--            <span class="icon fa-reply-all"></span>-->
            <div class="content">
              <p>Permite que a criança aceite melhor a comida da família, pois o leite materno tem o sabor e o cheiro dos alimentos que a mãe come.</p>
            </div>
          </article>

        </div>
      </section>
      <section>
        <h3>Para a mãe</h3>
        <div class="features" >
          <article>
            <span class="icon"><img src="<?php bloginfo("template_directory"); ?>/images/icon-flor.png" width="60" alt="" style="margin-top:55px"/></span>
            <div class="content">
              <p>Ajuda a reduzir o peso ganho na gestação.</p>
            </div>
          </article>
          <article>
            <span class="icon"><img src="<?php bloginfo("template_directory"); ?>/images/icon-flor.png" width="60" alt="" style="margin-top:55px"/></span>
            <div class="content">
              <p>Ajuda o útero a recuperar seu tamanho normal.</p>
            </div>
          </article>
          <article>
            <span class="icon"><img src="<?php bloginfo("template_directory"); ?>/images/icon-flor.png" width="60" alt="" style="margin-top:55px"/></span>
            <div class="content">
              <p>Diminui o sangramento pós-parto, reduzindo o risco de homrragia e anemia.</p>
            </div>
          </article>
          <article>
            <span class="icon"><img src="<?php bloginfo("template_directory"); ?>/images/icon-flor.png" width="60" alt="" style="margin-top:55px"/></span>
            <div class="content">
              <p>Diminui o risco de desenvolvimento de câncer de mama, de ovário e diabetes.</p>
            </div>
          </article>
          <article>
            <span class="icon"><img src="<?php bloginfo("template_directory"); ?>/images/icon-flor.png" width="60" alt="" style="margin-top:55px"/></span>
            <div class="content">
              <p>Ajuda no aumento do tempo entre as gestações.</p>
            </div>
          </article>

        </div>
      </section>



    </div>
  </div>

  <!-- Sidebar -->
  <div id="sidebar">
    <div class="inner">

      <?php get_sidebar(); ?>


    </div>
  </div>

</div>

<!-- Scripts -->
<script src="<?php bloginfo("template_directory"); ?>/assets/js/jquery.min.js"></script>
<script src="<?php bloginfo("template_directory"); ?>/assets/js/browser.min.js"></script>
<script src="<?php bloginfo("template_directory"); ?>/assets/js/breakpoints.min.js"></script>
<script src="<?php bloginfo("template_directory"); ?>/assets/js/util.js"></script>
<script src="<?php bloginfo("template_directory"); ?>/assets/js/main.js"></script>

</body>
</html>
