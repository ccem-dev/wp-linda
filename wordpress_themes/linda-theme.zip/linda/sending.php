<?php
ini_set ('display_errors', 1);

error_reporting (E_ALL);

$name = $_POST["name"];
$from = $_POST["email"];
$subject = "[SITE LINDA] ".$_POST["telephone"];
$message = $_POST["message"];

$to = "lindabrasil.poa@gmail.com";

if(!empty($name) && !empty($from) && !empty($subject) && !empty($message)){
  $headers = 'From: '.$from. "\r\n" .
    'X-Mailer: PHP/' . phpversion();

  if(mail($to, $subject, $message, $headers)){
    ?>
    <script>
      location.replace('https://www.ufrgs.br/linda/email/?sending=true');
    </script>
    <?
  } else {
    ?>
    <script>
      location.replace('https://www.ufrgs.br/linda/email/?sending=false');
    </script>
    <?
  }

} else {
  ?>
  <script>
    location.replace('https://www.ufrgs.br/linda/email/?sending=false');
  </script>
  <?
}

?>