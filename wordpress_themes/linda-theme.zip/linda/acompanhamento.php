<?php
/*Template Name:acompanhamento */

get_header();
?>
<!-- Wrapper -->
<div id="wrapper">

  <!-- Main -->
  <div id="main">
    <div class="inner">



      <!-- Content -->
      <section>
        <header class="major">
          <h2>Acompanhamento e Prevenção</h2>
        </header>
        <h2>Programa LINDA de prevenção do diabetes</h2>
        <ol>
          <li>Verificar se tem diabetes a partir de 6 a 8 semanas após o parto.</li>
          <li>Amamentar só no peito até os 6 meses e depois complementar as mamadas com outros alimentos.</li>
          <li>Controlar o peso corporal e adotar hábitos alimentares e de atividade física saudáveis.</li>
          <li>Verificar anualmente se desenvolveu diabetes.</li>
        </ol>
        <span class="image main"><img src="<?php bloginfo("template_directory"); ?>/images/avaliacao.png" alt=""/></span>


      </section>
      <span class="image main" style="opacity: 0.4;width: 8%; position: fixed;bottom:10px;left:10px;float: right;margin: 0;padding: 0" ><img src="<?php bloginfo("template_directory"); ?>/images/acompanhamento.png" alt=""/></span>


    </div>
  </div>

  <!-- Sidebar -->
  <div id="sidebar">
    <div class="inner">

      <?php get_sidebar(); ?>


    </div>
  </div>

</div>

<!-- Scripts -->
<script src="<?php bloginfo("template_directory"); ?>/assets/js/jquery.min.js"></script>
<script src="<?php bloginfo("template_directory"); ?>/assets/js/browser.min.js"></script>
<script src="<?php bloginfo("template_directory"); ?>/assets/js/breakpoints.min.js"></script>
<script src="<?php bloginfo("template_directory"); ?>/assets/js/util.js"></script>
<script src="<?php bloginfo("template_directory"); ?>/assets/js/main.js"></script>

</body>
</html>
