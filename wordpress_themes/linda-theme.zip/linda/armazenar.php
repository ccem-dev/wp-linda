<?php
/*Template Name:armazenar */

get_header();
?>
<!-- Wrapper -->
<div id="wrapper">

  <!-- Main -->
  <div id="main">
    <div class="inner">

      <!-- Content -->
      <section>
        <header class="major">
          <h2>Como armazenar o leite retirado</h2>
        </header>
        <h2>Preparando o Recipiente</h2>
        <span>- Frasco de vidro com tampa de plástico, sem rótulo.</span>
        <p>- Lavar o frasco e ferver em uma panela com água por 15 minutos. Deixar escorrer em pano limpo.</p>


      </section>
      <section>
        <h2>Armazenamento</h2>
        <span>- Anote na tampa a data e hora da coleta.</span><br>
        <span>- Guarde o frasco fechado em freezer ou geladeira imediatamente após a coleta.</span>
        <p>- O leite pode ser armazenado em <b>geladeira</b> por até <b>12 horas</b> e no <b>freezer ou congelador</b> por até <b>15 dias</b>.</p>

      </section>
      <section>
        <h2>Descongelamento</h2>
        <span>- Descongelar na parte baixa da geladeira.</span>
        <p>- Amornar o leite em banho-maria agitando levemente o vidro.</p>

      </section>
      <span class="image main" style="opacity: 0.4;width: 8%; position: fixed;bottom:10px;right:10px;float: right;margin: 0;padding: 0" ><img src="<?php bloginfo("template_directory"); ?>/images/armazenar.png" alt=""/></span>


    </div>
  </div>

  <!-- Sidebar -->
  <div id="sidebar">
    <div class="inner">

      <?php get_sidebar(); ?>


    </div>
  </div>

</div>

<!-- Scripts -->
<script src="<?php bloginfo("template_directory"); ?>/assets/js/jquery.min.js"></script>
<script src="<?php bloginfo("template_directory"); ?>/assets/js/browser.min.js"></script>
<script src="<?php bloginfo("template_directory"); ?>/assets/js/breakpoints.min.js"></script>
<script src="<?php bloginfo("template_directory"); ?>/assets/js/util.js"></script>
<script src="<?php bloginfo("template_directory"); ?>/assets/js/main.js"></script>

</body>
</html>
